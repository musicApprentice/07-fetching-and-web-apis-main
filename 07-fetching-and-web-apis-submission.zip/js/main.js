import { fetchCurrentTemperature } from "./fetchCurrentTemperature.js";
// TODO - Now its your turn to make the working example! :)
const coord = { lat: 40, lon: 90 };
fetchCurrentTemperature(coord);
//# sourceMappingURL=main.js.map