export function fetchUniversityWeather(universityQuery, transformName) {
    // TODO
    return new Promise(res => res({ totalAverage: NaN }));
}
export function fetchUMassWeather() {
    // TODO
    return new Promise(res => res({ totalAverage: NaN }));
}
export function fetchUCalWeather() {
    // TODO
    return new Promise(res => res({ totalAverage: NaN }));
}
//# sourceMappingURL=universityWeather.js.map